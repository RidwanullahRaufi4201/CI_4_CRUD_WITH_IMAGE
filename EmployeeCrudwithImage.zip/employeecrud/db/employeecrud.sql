-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2023 at 12:39 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `employeecrud`
--

-- --------------------------------------------------------

--
-- Table structure for table `empdocument`
--

CREATE TABLE `empdocument` (
  `id` varchar(55) NOT NULL,
  `fileName` varbinary(77) NOT NULL,
  `filepath` varchar(500) NOT NULL,
  `type` varchar(55) NOT NULL,
  `uploadTime` int(11) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `empdocument`
--

INSERT INTO `empdocument` (`id`, `fileName`, `filepath`, `type`, `uploadTime`) VALUES
('Shahidullah', 0x66616973616c2e6a7067, 'uploads/1680069606_c1d223d75eff723f0e0d.jpg', 'jpg', 2147483647),
('Shahidullah', 0x46595070726f706f73616c2e706466, 'uploads/1680069606_2e01df3da1776910f902.pdf', 'pdf', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `name` varchar(55) NOT NULL,
  `gender` varchar(8) NOT NULL,
  `email` varchar(66) NOT NULL,
  `occupation` varchar(77) NOT NULL,
  `education_level` varchar(77) NOT NULL,
  `last_job` varchar(66) NOT NULL,
  `joining_date` date DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `gender`, `email`, `occupation`, `education_level`, `last_job`, `joining_date`) VALUES
(72, 'Irfanullah', 'male', 'i.raufi.afg@gmail.com', 'Student', 'BSC', 'Driver', '2023-03-20'),
(142, 'Ridwanullah', 'female', 'r.raufi.afg@gmail.com', 'student', 'BSCS', 'Driver', '2023-03-25'),
(143, 'Shahidullah', 'male', 's.raufi.afg@gmail.com', 'student', 'master', 'Student', '2023-03-28'),
(144, 'Tawheed', 'male', 't.raufi.afg@gmail.com', 'student', 'BSC', 'Teacher', '2023-03-28');

-- --------------------------------------------------------

--
-- Table structure for table `lastjob`
--

CREATE TABLE `lastjob` (
  `id` int(11) NOT NULL,
  `role` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lastjob`
--

INSERT INTO `lastjob` (`id`, `role`) VALUES
(1, 'Manager'),
(3, 'Teacher'),
(5, 'Student'),
(6, 'Driver'),
(7, 'CEO');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lastjob`
--
ALTER TABLE `lastjob`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;

--
-- AUTO_INCREMENT for table `lastjob`
--
ALTER TABLE `lastjob`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?= $this->extend('Layout/LayoutPage') ?>



<?= $this->section('content') ?>
    
<div class="container p-4">
     <div class="row">
        <div class="col-md-6">
        <div style="width:400px;margin:auto;">
           <canvas id="myChart1"></canvas>
         </div>
        </div>
        <div class="col-md-6">
        <div style="width:400px;margin:auto;">
           <canvas id="myChart2"></canvas>
         </div>
        </div>
     </div>
     <div class="row">
        <div class="col-md-6">
        <div style="width:400px;margin:auto;">
           <canvas id="myChart3"></canvas>
         </div>
        </div>
        <div class="col-md-6">
        <div style="width:400px;margin:auto;">
           <canvas id="myChart4"></canvas>
         </div>
        </div>
     </div>
</div>


<script>
    $(document).ready(function(){



        loadchart('pie','#myChart1')
        loadchart('doughnut','#myChart2')
        loadchart('line','#myChart3')
        loadchart('bar','#myChart4')
    function loadchart(CharType,element){
   
  const ctx = $(element);
     var monday=0,tuesday=0,wednesday=0,thursday=0,friday=0;
  $.ajax({
    url:'getCount',
    method:'GET',
    success:function(data)
    {
        tuesday=data
        
    }
  })
  $.ajax({
    url:'getCount1',
    method:'GET',
    success:function(data)
    {
      monday=data
      
        
    }
  })
  $.ajax({
    url:'getCount2',
    method:'GET',
    success:function(data)
    {
      friday=data
        
    }
  })
  $.ajax({
    url:'getCount3',
    method:'GET',
    success:function(data)
    {
      thursday=data
        
    }
  })
  $.ajax({
    url:'getCount4',
    method:'GET',
    success:function(data)
    {
      wednesday=data
        
    }
  })

setTimeout(function(){
  new Chart(ctx, {
    type: CharType,
    data: {
      labels: ['wednesday', 'Tursday', 'Friday', 'Monday','Tuesday'],
      datasets: [{
        label: "employee Hiring",
        data: [wednesday, thursday, friday,monday,tuesday],
        borderWidth: 1
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
},1000)
 
   
    }




    })
</script>
<?= $this->endSection() ?>>
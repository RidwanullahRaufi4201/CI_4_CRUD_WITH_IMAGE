<div class="container-fluid m-0 p-0">
<nav class="navbar navbar-expand-lg navbar-light bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand text-white  fw-bold" href="http://localhost/employeecrud/public/"><img src="<?php echo base_url('assets/logo.jpg')?>" style="width:40px" class="rounded-pill" alt="">  IG TECH SERVICES</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active text-white fw-bold" aria-current="page" href="http://localhost/employeecrud/public/">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white fw-bold" href="index">Employee crud</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white fw-bold" href="file-upload">Employee document </a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white fw-bold" href="stripe"  >Stripe</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white fw-bold" href="animate"  >Animation</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white fw-bold" href="dashboard" >Dashboard</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-12 m-4">
             <h4 class="text-center">Welcome to Employee Management Application </h4>
        </div>
    </div>
</div>
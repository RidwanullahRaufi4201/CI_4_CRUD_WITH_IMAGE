<?= $this->extend('Layout/LayoutPage') ?>



<?= $this->section('content') ?>
<style>
    .debug-view .debug-view-path{
    display: none;
   }
</style>

<div class="container">
    <h2 class="text-center mt-5 mb-3">Multitple File Upload</h2>
    <div class="card">
        <div class="card-body">
         <?php if (session()->getFlashdata('success')) : ?>
                <div class="alert alert-success">
                    <b><?php echo session()->getFlashdata('success') ?></b>
                </div>
            <?php endif ?>
            <?php if (session()->getFlashdata('error')) : ?>
                <div class="alert alert-danger">
                    <b><?php echo session()->getFlashdata('error') ?></b>
                </div>
            <?php endif ?>
  
  
            <form class="row" method="post" action="<?php echo base_url('multiple-file-upload')  ?>" enctype="multipart/form-data">
                  <div class="col-auto">
                  <select class="form-select"  id="employeename" name="name" aria-label="Default select example">
                  <option selected>select Employee</option>
                  </select>
                </div>
                <div class="col-auto">
                    <input type="file" name="fileuploads[]" class=" form-control" multiple >
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-outline-primary mb-3">Upload Files</button>
                </div>
            </form>
            <table class="table table-bordered mt-3">
                <thead>
                    <tr>
                        <th>Employee Name</th>
                        <th>file</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody >
                    <?php
                      
                     foreach($fileUpload as $file){
                       
                    ?>
                    <tr>
                     <td><?php echo  $file->id ?></td>
                     <td>
                        <?php 
                          $file_ext = pathinfo($file->fileName,PATHINFO_EXTENSION);
                          $allowed_images=['jpg','png','jpeg'];
                          
                          if(in_array($file_ext,$allowed_images)){
                        ?>
                        <img src="<?php echo base_url('uploads/'.$file->fileName)?>" height="100" width="100" alt="">
                        <?php }else if($file_ext=='pdf'||$file_ext=='doc'||$file_ext=='docx'){ ?>
                          <iframe src="<?php echo base_url('uploads/'.$file->fileName)?>" height="100" width="100" frameborder="0"></iframe>
                        <?php } ?>
                       

                    </td>
                     <td > <a href="deletefile/<?php echo $file->fileName?>" class="btn btn-sm btn-danger">Delete</a></td>
                     </tr>
                    <?php }?>
               
                </tbody>
                      
            </table>
        </div>
    </div>
  
</div>


<script>
    $(document).ready(function(){
       

             $.ajax({
                url:'getnames/getAllName',
                type:'GET',
                success:function(response)
                {
                    var option="";
                    $(response.name).each(function(key,value){
                    
                        $('#employeename').append("<option value="+value.name+">"+value.name+"</option>");
                       
                    })

                }
             })


            //  $(".btn-delete").click(function(e){
            //     e.preventDefault()
                
            //        var filename=$(this).data('name')
            //       alert(filename)
                  
            //        $.ajax({
            //         url:'deletefile',
            //         method:'POST',
            //         data:{'name':filename},
            //         success:function(res)
            //         {
                       
            //         }
                    
            //        })
             


            //  })
               


    })
</script>

<?= $this->endSection() ?>>
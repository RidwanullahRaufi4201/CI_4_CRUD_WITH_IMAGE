

<?= $this->extend('Layout/LayoutPage') ?>


<?= $this->section('content') ?>
<?= $this->endSection() ?>
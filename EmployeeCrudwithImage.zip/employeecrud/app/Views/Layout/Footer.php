<div class="container-fluid m-0 p-0 bg-primary p-3 mt-5">




<div class="row justify-content-center">
    <div class="col-md-4 text-white text-center">
          <h6>copyright#2023</h5>
    </div>
    
  
</div>
</div>


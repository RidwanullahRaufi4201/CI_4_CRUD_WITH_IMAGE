<?php


namespace App\Models;

use CodeIgniter\Model;

class EmployeeModel extends Model
{
    protected $table='employee';
    protected $allowedFields = ['name', 'gender','email','occupation','education_level','last_job','joining_date'];
}
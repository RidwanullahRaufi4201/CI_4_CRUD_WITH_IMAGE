<?php


namespace App\Models;

use CodeIgniter\Model;

class LastJob extends Model
{
    protected $table='LastJob';
    protected $allowedFields = ['role'];
}
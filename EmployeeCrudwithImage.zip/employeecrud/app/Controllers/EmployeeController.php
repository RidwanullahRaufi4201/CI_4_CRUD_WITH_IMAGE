<?php

namespace App\Controllers;

use App\Models\Document;
use App\Models\EmployeeModel;
use App\Models\LastJob;
use CodeIgniter\Commands\Utilities\Routes\FilterFinder;

class EmployeeController extends BaseController
{
    public function showHeadeer()
    {
        $emp=new EmployeeModel();
        $data['emp_all']=$emp->findAll();
     
        return view('Layout/index',$data);
    }
    public function index()
    { 
        
        return view('Layout/Welcome_Page');
    }


    public function check_email()
    {
            $email=$this->request->getPost('email');
            $employee=new EmployeeModel();
            $data['emps']=$employee->findAll(); 
            $flag=true;
         
            foreach($data['emps'] as $emp)
            {
                    if($emp['email']==$email)
                    {
                         $flag=false;
                    }
            }
        
            if($flag)
            {
                return 'no';
            }else{
                return 'yes';
            }

            
    }
    public function save_emp()
    {
        
        $data=$_POST;

        $employee=new EmployeeModel();

         if(isset($_POST['id']) && !empty($_POST['id'])){
                 // $employee->find($_POST['id']);
                  $employee->update($_POST['id'],$data);
         }else{
            $employee->insert($data);
         }
   
       
    
    }

    public function getStudents()
    {
        $employee=new EmployeeModel();
        $data['employee']=$employee->findAll();
        return $this->response->setJSON($data);
    }

    public function delete_emp()
    {
        $id= $this->request->getPost('emp_id');
        $employee=new EmployeeModel();
        if($employee->delete($id))
        {
            return 1;
        }
        
    
    }
    public function view_emp()
    {
        $id= $this->request->getPost('emp_id');
         $employee=new EmployeeModel();
         $data['employee']=$employee->find($id);
        return $this->response->setJSON($data);
        //return $id;
    
    }
    public function edit_emp()
    {
        $id= $this->request->getPost('emp_id');
        $employee=new EmployeeModel();
        $data['employee']=$employee->find($id);
       return $this->response->setJSON($data);
        

    }



    public function getDashboard()
    {
        return view('layout/dashboard');
    }


    public function generate_pdf()
    {

        $emp=new EmployeeModel();
        $data['emp_all']=$emp->findAll();
        $table='<table border="1" style="width:700px;margin:auto"> <tr style="background:black;color:white"><td>name </td><td>gender </td><td>email </td>
        <td>Occupation </td><td>education level </td><td>last job </td><td>joining date </td></tr>';

         foreach($data['emp_all'] as $emp)
         {
               $name=$emp['name'];
               $gender=$emp['gender'];
               $email=$emp['email'];
               $ocupation=$emp['occupation'];
               $educationlevel=$emp['education_level'];
               $lastjob=$emp['last_job'];
               $dateofjoining=$emp['joining_date'];

              $table.="<tr> <td>$name</td><td>$gender</td><td>$email</td>
              <td>$ocupation</td> <td>$educationlevel</td><td>$lastjob</td> <td>$dateofjoining</td></tr>";
         }
         $table.='</table>';

          $dompdf=new \Dompdf\Dompdf();
          
          $dompdf->loadHtml($table);
          $dompdf->setPaper('A4','portrait');
          $dompdf->render();
          $dompdf->stream('employee-list');

    }


    public function generate_pdf_single($id)
    {
        $emp=new EmployeeModel();
        $data=$emp->find($id);
        $html='<div>';

        
               $name=$data['name'];
               $html.="<div>Name   :<strong> $name </strong></div>";
               $gender=$data['gender'];
               $html.="<div>Gender :<strong>  $gender </strong></div>";
               $email=$data['email'];
               $html.="<div>Email :<strong>   $email </strong></div>";
               $ocupation=$data['occupation'];
               $html.="<div>Occupation :<strong>   $ocupation </strong></div>";
               $educationlevel=$data['education_level'];
               $html.="<div>Education Level :<strong> $educationlevel </strong></div>";
               $lastjob=$data['last_job'];
               $html.="<div>Last Job :<strong> $lastjob </strong></div>";
               $dateofjoining=$data['joining_date'];
               $html.="<div>Joining Date :<strong> $dateofjoining </strong></div>";


         
         $html.='</div>';

          $dompdf=new \Dompdf\Dompdf();
          
          $dompdf->loadHtml($html);
          $dompdf->setPaper('A4','portrait');
          $dompdf->render();
          $dompdf->stream($name.'-report');
    }





    public function getCount()
    {
        
        $emp=new EmployeeModel();
        $emp->where('joining_date','2023-03-21');
        $emp->selectCount('joining_date');
        $data=$emp->findAll();
        return $data[0]['joining_date'];
    }

    public function getCount1()
    {
        
        $emp=new EmployeeModel();
        $emp->where('joining_date','2023-03-20');
        $emp->selectCount('joining_date');
        $data=$emp->findAll();
        return $data[0]['joining_date'];
    }

    public function getCount2()
    {
        
        $emp=new EmployeeModel();
        $emp->where('joining_date','2023-03-27');
        $emp->selectCount('joining_date');
        $data=$emp->findAll();
        return $data[0]['joining_date'];
    }

    public function getCount3()
    {
        
        $emp=new EmployeeModel();
        $emp->where('joining_date','2023-03-28');
        $emp->selectCount('joining_date');
        $data=$emp->findAll();
        return $data[0]['joining_date'];
    }

    public function getCount4()
    {
        
        $emp=new EmployeeModel();
        $emp->where('joining_date','2023-03-29');
        $emp->selectCount('joining_date');
        $data=$emp->findAll();
        return $data[0]['joining_date'];
    }

    public function update_emp()
    {
       $id=$this->request->getPost('id');
       $email=$this->request->getPost('email');

       $employee=new EmployeeModel();
       $singleEmployee=$employee->find($id);
       $isprocced=true;
       
      
               if($singleEmployee['email']==$email)
               {
                    $isprocced=false;
               }
       

       if($isprocced){
       
       $data['emps']=$employee->findAll(); 
       $flag=true;
    
       foreach($data['emps'] as $emp)
       {
               if($emp['email']==$email)
               {
                    $flag=false;
               }
       }
   
       if($flag)
       {
           return 'no';
       }else{
           return 'yes';
       }
    }else{

        $data=[
            
            'name'=>$this->request->getPost('name'),
            'gender'=>$this->request->getPost('gender'),
            'email'=>$this->request->getPost('email'),
            'occupation'=>$this->request->getPost('occupation'),
            'education_level'=>$this->request->getPost('education_level'),
            'last_job'=>$this->request->getPost('last_job'),
            
        ];
       
        // $employee=new EmployeeModel();
        
         $employee->update($id,$data);
    }
      

    }


    public function getAllName()
    {
        $emp=new EmployeeModel();
        $emp->select('id,name');
        $data['name']=$emp->findAll();
        return $this->response->setJSON($data);

    }

    public function getAlldate()
    {
        $emp=new EmployeeModel();
        $emp->select('joining_date','last_job');
        $data['name']=$emp->findAll();
        return $this->response->setJSON($data);

    }
    public function getLastJob()
    {
        $emp=new EmployeeModel();
        $emp->select('last_job');
        $data['name']=$emp->findAll();
        return $this->response->setJSON($data);



    }

    public function getallemp()
    {
           $lastjob=$this->request->getPost('last_job');
           $emp=new EmployeeModel();
          
           $data['allemp']=$emp->find('last_job',$lastjob);

           return $this->response->setJSON($data);
    }


    public function getAllLastjob()
    {
          $lastJobs=new LastJob();
          $data['lastjobs']=$lastJobs->findAll();
          return $this->response->setJSON($data);
    }


    
   

    public function animateImages()
    {
        return view('Layout/animate');
    }
}

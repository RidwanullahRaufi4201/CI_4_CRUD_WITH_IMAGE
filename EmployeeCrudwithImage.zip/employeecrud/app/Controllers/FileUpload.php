<?php
 
namespace App\Controllers;
 
use App\Controllers\BaseController;
use App\Models\Document;
 
class FileUpload extends BaseController
{
 
    public function index()
    {
           $fileUploadModel = new Document();
         
        return view('Layout/document',['fileUpload'=> $fileUploadModel->findAll()]);
    }

   
 
    public function multipleUpload() 
    {
        $filesUploaded = 0;
    
        if($this->request->getFileMultiple('fileuploads')&&$this->request->getPost('name'))
        {
            $files = $this->request->getFileMultiple('fileuploads');
          
 
            foreach ($files as $file) {
 
                if ($file->isValid() && ! $file->hasMoved())
                {
                   // return $this->request->getPost('empid');
                    $newName = $file->getRandomName();
                    $file->move('uploads');
                    $filepath='uploads/' . $newName;
                    $data = [
                        'id'=>$this->request->getPost('name'),
                        'fileName' => $file->getClientName(),
                        'filepath' => $filepath,
                        'type' => $file->getClientExtension()
                    ];
                    $fileUploadModel = new Document();
                    $fileUploadModel->insert($data);
                    $filesUploaded++;
                }
                 
            }
 
        }
 
        if($filesUploaded <= 0) {
            return redirect()->back();
        }
 
        return redirect()->back();
 
    }


    public function deleteFile($name)
    {   
    
       
         $fileUploadModel = new Document();
    
            unlink('uploads/'.$name);
            $fileUploadModel->where('fileName', $name);
            $fileUploadModel->delete();
            return redirect()->back();

    }
}